/* commit.h.in. Creates commit.h during a cmake run */

/* git information */
#define COMMIT "ac58278"
