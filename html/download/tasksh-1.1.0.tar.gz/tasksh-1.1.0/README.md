# Disclaimer during ongoing development

The development branch is a work in progress and may not pass all quality tests,
therefore it may harm your data. While we welcome bug reports from the
development branch, we do not guarantee proper or timely fixes.

- Make proper backups.
- Broken functionality may arise from ongoing development work.
- Be aware that using the development branch involves risks.

---

Thank you for taking a look at tasksh!!

---

Tasksh is released under the MIT license. For details check the LICENSE file.
