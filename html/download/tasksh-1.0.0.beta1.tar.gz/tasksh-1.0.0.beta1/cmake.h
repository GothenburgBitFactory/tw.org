/* cmake.h.in. Creates cmake.h during a cmake run */

/* Product identification */
#define PRODUCT_TASKSH 1

/* Package information */
#define PACKAGE           "tasksh"
#define VERSION           "1.0.0.beta1"
#define PACKAGE_BUGREPORT "support@taskwarrior.org"
#define PACKAGE_NAME      "tasksh"
#define PACKAGE_TARNAME   "tasksh"
#define PACKAGE_VERSION   "1.0.0.beta1"
#define PACKAGE_STRING    "tasksh 1.0.0.beta1"

#define CMAKE_BUILD_TYPE  ""

/* Localization */
#define PACKAGE_LANGUAGE 1
#define LANGUAGE_ENG_USA 1

/* git information */
#define HAVE_COMMIT

/* cmake information */
#define HAVE_CMAKE
#define CMAKE_VERSION "2.8.11.1"

/* Compiling platform */
/* #undef LINUX */
#define DARWIN
/* #undef CYGWIN */
/* #undef FREEBSD */
/* #undef OPENBSD */
/* #undef NETBSD */
/* #undef HAIKU */
/* #undef SOLARIS */
/* #undef KFREEBSD */
/* #undef GNUHURD */
/* #undef UNKNOWN */

/* Found the Readline library */
#define HAVE_READLINE

/* Found the pthread library */
#define HAVE_LIBPTHREAD

/* Found wordexp.h */
/* #undef HAVE_WORDEXP */

