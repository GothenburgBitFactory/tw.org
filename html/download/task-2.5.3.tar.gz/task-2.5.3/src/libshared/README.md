libshared
=========

A git submodule used by multiple projects. Not to be released or packaged
independently. All project tarballs will include libshared, so this is a
development-only internal proejct.

Branching
---------

Development for libshared is done on the master branch only.

Each time a project is released that uses libshared, an appropriate tag is
added to the corresponding commit.

A project may choose to release with any libshared commit.

---
