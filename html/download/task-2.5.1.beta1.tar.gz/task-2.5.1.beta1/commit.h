/* commit.h.in. Creates commit.h during a cmake run */

/* git information */
#define COMMIT "2ca3fd5"
