See [Developing Taskwarrior](./doc/devel/contrib/README.md).
