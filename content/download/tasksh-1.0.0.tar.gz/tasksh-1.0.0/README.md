Thank you for taking a look at tasksh!!

---

Tasksh is released under the MIT license. For details check the LICENSE file.
