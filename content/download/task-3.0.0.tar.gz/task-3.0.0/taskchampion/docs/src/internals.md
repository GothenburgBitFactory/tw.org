# Internal Details

The following sections get into the details of how TaskChampion works.
None of this information is necessary to use TaskChampion, but might be helpful in understanding its behavior.
Developers of TaskChampion and of tools that integrate with TaskChampion should be familiar with this information.
