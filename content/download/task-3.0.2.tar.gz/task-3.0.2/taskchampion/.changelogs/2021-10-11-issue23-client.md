- The `avoid_snapshots` configuration value, if set, will cause the replica to
  avoid creating snapshots unless required.
