- The SQLite server storage schema has changed incompatibly, in order to add support for snapshots.
  As this is not currently ready for production usage, no migration path is provided except deleting the existing database.
