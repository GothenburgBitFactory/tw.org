Copyright (C) Andrew Savchenko - All Rights Reserved
All files within this folder are proprietary and reserved for the use by TaskChampion project.
