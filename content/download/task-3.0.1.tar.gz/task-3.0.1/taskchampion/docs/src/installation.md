# Installation

As this is currently in development, installation is by cloning the repository and running "cargo build".
